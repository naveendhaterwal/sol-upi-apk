"use client";

import {
  Alert02Icon,
  ArrowRight01Icon,
  CheckmarkCircle01Icon,
} from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react";
import { useWallet } from "@solana/wallet-adapter-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { FancyButton } from "@/components/ui/fancy-button";
import {
  appendPayment,
  formatBaseUnits,
} from "@/lib/cloak/payment-history";
import { checkPreflightBalance } from "@/lib/cloak/preflight";
import { toBaseUnits } from "@/lib/cloak/tokens";
import { useBatchPayroll } from "@/lib/cloak/use-batch-payroll";
import { useWalletBalances } from "@/lib/cloak/use-wallet-balances";
import { solanaConfig } from "@/lib/solana/config";
import { solscanTxUrl } from "@/lib/solana/explorer";
import { markMemberPaid } from "@/lib/team/storage";
import type { DueGroup } from "@/lib/team/use-due-members";
import { toast } from "@/lib/toast";
import { cn } from "@/lib/utils";

const VARIABLE_FEE_BPS = 30n;
const FIXED_FEE_LAMPORTS = 5_000_000n;

type GroupOutcome = {
  confirmed: number;
  failed: number;
  total: number;
  depositSignature: string | null;
};

export function DueRunDialog({
  open,
  groups,
  onClose,
}: {
  open: boolean;
  groups: DueGroup[];
  onClose: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={(v) => (v ? null : onClose())}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Run scheduled payments</DialogTitle>
          <DialogDescription>
            One signature per token group. Each batch shields, then pays each
            recipient privately.
          </DialogDescription>
        </DialogHeader>

        {open && <DueRunBody groups={groups} onClose={onClose} />}
      </DialogContent>
    </Dialog>
  );
}

function DueRunBody({
  groups,
  onClose,
}: {
  groups: DueGroup[];
  onClose: () => void;
}) {
  const wallet = useWallet();
  const batch = useBatchPayroll();
  const walletBalances = useWalletBalances();

  // Snapshot the groups at open time. Once a payment succeeds, markMemberPaid
  // updates lastPaidAt and the upstream `groups` prop drops that member from
  // the due list, which would otherwise empty the dialog mid-run.
  const [snapshot] = React.useState<DueGroup[]>(() => groups);

  const [activeMint, setActiveMint] = React.useState<string | null>(null);
  const [outcomes, setOutcomes] = React.useState<Record<string, GroupOutcome>>({});
  const [allRunning, setAllRunning] = React.useState(false);

  const isRunning = batch.status === "running" || allRunning;
  const remainingGroups = snapshot.filter((g) => !outcomes[g.mint]);

  const runGroup = React.useCallback(async (group: DueGroup) => {
    if (!wallet.publicKey) return;
    if (batch.status !== "idle") batch.reset();

    setActiveMint(group.mint);

    const fixedDeducted =
      group.token.id === "SOL" ? FIXED_FEE_LAMPORTS : 0n;
    const rows = group.members
      .filter((m) => m.schedule)
      .map((m, i) => {
        const amountBaseUnits = toBaseUnits(
          m.schedule!.amount,
          group.token.decimals,
        );
        const variableFee = (amountBaseUnits * VARIABLE_FEE_BPS) / 10_000n;
        const net = amountBaseUnits - variableFee - fixedDeducted;
        return {
          memberId: m.id,
          amountBaseUnits,
          netBaseUnits: net < 0n ? 0n : net,
          recipient: m.wallet,
          rowId: i + 1,
        };
      });

    const idToRow = new Map(rows.map((r) => [r.rowId, r]));

    const totalAmount = rows.reduce(
      (acc, r) => acc + r.amountBaseUnits,
      0n,
    );
    const preflight = checkPreflightBalance({
      amountBaseUnits: totalAmount,
      decimals: group.token.decimals,
      symbol: group.token.id,
      tokenId: group.token.id,
      operations: rows.length,
      walletBalances: walletBalances.balances,
    });
    if (!preflight.ok) {
      toast.error(preflight.reason, { description: preflight.description });
      setActiveMint(null);
      return;
    }

    const outcome = await batch.run({
      rows: rows.map((r) => ({
        id: r.rowId,
        recipient: r.recipient,
        amountBaseUnits: r.amountBaseUnits,
        netBaseUnits: r.netBaseUnits,
      })),
      mint: group.token.mint,
      tokenId: group.token.id,
      decimals: group.token.decimals,
    });

    if (!outcome) {
      setActiveMint(null);
      return;
    }

    const sender = wallet.publicKey.toBase58();

    for (const result of outcome.results) {
      if (!result.ok) continue;
      const row = idToRow.get(result.id);
      if (!row) continue;

      markMemberPaid(solanaConfig.cluster, row.memberId);

      appendPayment(sender, solanaConfig.cluster, {
        id: result.payoutSig,
        cluster: solanaConfig.cluster,
        sender,
        recipient: row.recipient,
        token: group.token.id,
        mint: group.token.mint.toBase58(),
        decimals: group.token.decimals,
        amountRaw: row.amountBaseUnits.toString(),
        netRaw: row.netBaseUnits.toString(),
        depositSignature: outcome.depositSignature,
        withdrawSignature: result.payoutSig,
        timestamp: Date.now(),
        batchId: outcome.depositSignature,
        source: "recurring",
      });
    }

    setOutcomes((prev) => ({
      ...prev,
      [group.mint]: {
        confirmed: outcome.confirmed,
        failed: outcome.failed,
        total: outcome.total,
        depositSignature: outcome.depositSignature,
      },
    }));
    setActiveMint(null);
    batch.reset();
  }, [batch, wallet.publicKey, walletBalances]);

  const runAll = React.useCallback(async () => {
    if (!wallet.publicKey) return;
    setAllRunning(true);
    try {
      const pending = snapshot.filter((g) => !outcomes[g.mint]);
      for (const group of pending) {
        await runGroup(group);
      }
    } finally {
      setAllRunning(false);
    }
  }, [snapshot, outcomes, runGroup, wallet.publicKey]);

  const totalDueRows = snapshot.reduce((acc, g) => acc + g.members.length, 0);
  const remainingCount = remainingGroups.length;
  const completedCount = snapshot.length - remainingCount;
  const showPayAll = remainingCount > 0;
  const allDone = snapshot.length > 0 && remainingCount === 0;

  return (
    <>
      {!wallet.connected && (
        <div className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-[12.5px] text-destructive">
          <HugeiconsIcon icon={Alert02Icon} size={12} strokeWidth={2.2} />
          Connect your wallet to run scheduled payments.
        </div>
      )}

      {showPayAll && (
        <div className="flex flex-col gap-3 rounded-xl border border-primary/40 bg-primary/10 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-4">
          <div className="flex flex-col">
            <p className="text-[13.5px] font-medium text-foreground">
              Pay all {totalDueRows} recipient
              {totalDueRows === 1 ? "" : "s"} in one click
            </p>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              {remainingCount === 1
                ? "1 wallet signature"
                : `${remainingCount} wallet signatures`}{" "}
              · one shielded deposit per token, then private payouts
              {completedCount > 0 && ` · ${completedCount} already done`}
            </p>
          </div>
          <FancyButton
            type="button"
            variant="primary"
            size="md"
            disabled={isRunning || !wallet.connected}
            onClick={runAll}
            className="self-stretch sm:self-auto"
          >
            {allRunning
              ? activeMint
                ? `Paying ${tokenLabelFor(snapshot, activeMint)}…`
                : "Running…"
              : "Pay all"}
            {!allRunning && (
              <HugeiconsIcon
                icon={ArrowRight01Icon}
                size={14}
                strokeWidth={2.2}
              />
            )}
          </FancyButton>
        </div>
      )}

      {allDone && <RunSummary snapshot={snapshot} outcomes={outcomes} />}

      <div className="flex flex-col gap-4">
        {snapshot.map((group) => {
          const outcome = outcomes[group.mint];
          const running = activeMint === group.mint && isRunning;
          return (
            <GroupCard
              key={group.mint}
              group={group}
              outcome={outcome}
              running={running}
              disabled={isRunning || !wallet.connected}
              onRun={() => runGroup(group)}
            />
          );
        })}
      </div>

      <DialogFooter>
        <Button
          type="button"
          variant="outline"
          onClick={onClose}
          disabled={isRunning}
        >
          {remainingCount === 0 ? "Done" : "Close"}
        </Button>
      </DialogFooter>
    </>
  );
}

function tokenLabelFor(groups: DueGroup[], mint: string): string {
  return groups.find((g) => g.mint === mint)?.token.id ?? "";
}

function RunSummary({
  snapshot,
  outcomes,
}: {
  snapshot: DueGroup[];
  outcomes: Record<string, GroupOutcome>;
}) {
  let confirmed = 0;
  let failed = 0;
  let total = 0;
  const perToken: { tokenId: string; decimals: number; net: bigint }[] = [];

  for (const group of snapshot) {
    const outcome = outcomes[group.mint];
    if (!outcome) continue;
    confirmed += outcome.confirmed;
    failed += outcome.failed;
    total += outcome.total;

    let net = 0n;
    for (const m of group.members) {
      if (!m.schedule) continue;
      try {
        const gross = toBaseUnits(m.schedule.amount, group.token.decimals);
        const variable = (gross * VARIABLE_FEE_BPS) / 10_000n;
        const fixed =
          group.token.id === "SOL" ? FIXED_FEE_LAMPORTS : 0n;
        const memberNet = gross - variable - fixed;
        net += memberNet < 0n ? 0n : memberNet;
      } catch {
        // ignore per-member parse errors; the row would have failed validation
      }
    }
    perToken.push({
      tokenId: group.token.id,
      decimals: group.token.decimals,
      net,
    });
  }

  const allOk = failed === 0;

  return (
    <div
      className={cn(
        "flex flex-col gap-2 rounded-xl border p-4",
        allOk
          ? "border-primary/40 bg-primary/10"
          : "border-destructive/40 bg-destructive/10",
      )}
    >
      <div className="flex items-start gap-3">
        <span
          aria-hidden="true"
          className={cn(
            "grid size-8 shrink-0 place-items-center rounded-full",
            allOk ? "bg-primary/20 text-primary" : "bg-destructive/20 text-destructive",
          )}
        >
          <HugeiconsIcon
            icon={allOk ? CheckmarkCircle01Icon : Alert02Icon}
            size={15}
            strokeWidth={2.2}
          />
        </span>
        <div className="flex flex-col">
          <p className="text-[13.5px] font-medium text-foreground">
            {allOk
              ? `Paid ${confirmed} recipient${confirmed === 1 ? "" : "s"} privately`
              : `${confirmed} of ${total} paid · ${failed} failed`}
          </p>
          <p className="mt-0.5 text-[11.5px] text-muted-foreground">
            {perToken
              .map(
                (t) =>
                  `${formatBaseUnits(t.net.toString(), t.decimals)} ${t.tokenId}`,
              )
              .join(" · ")}
            {" "}sent · view receipts in History.
          </p>
        </div>
      </div>
    </div>
  );
}

function GroupCard({
  group,
  outcome,
  running,
  disabled,
  onRun,
}: {
  group: DueGroup;
  outcome?: GroupOutcome;
  running: boolean;
  disabled: boolean;
  onRun: () => void;
}) {
  const totalRaw = group.members.reduce((acc, m) => {
    if (!m.schedule) return acc;
    try {
      return acc + toBaseUnits(m.schedule.amount, group.token.decimals);
    } catch {
      return acc;
    }
  }, 0n);
  const totalDisplay = formatBaseUnits(totalRaw.toString(), group.token.decimals);

  return (
    <div
      className={cn(
        "flex flex-col gap-3 rounded-xl border bg-card/40 p-4",
        outcome && outcome.failed === 0
          ? "border-primary/30"
          : outcome && outcome.failed > 0
            ? "border-destructive/30"
            : "border-border",
      )}
    >
      <header className="flex items-center justify-between gap-3">
        <div className="flex flex-col">
          <p className="text-[13.5px] font-medium text-foreground">
            {group.members.length} {group.token.id} payment
            {group.members.length === 1 ? "" : "s"}
          </p>
          <p className="font-mono text-[11.5px] text-muted-foreground">
            Total {totalDisplay} {group.token.id}
          </p>
        </div>

        {outcome ? (
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11.5px] font-medium",
              outcome.failed === 0
                ? "border-primary/40 bg-primary/15 text-primary"
                : "border-destructive/40 bg-destructive/10 text-destructive",
            )}
          >
            <HugeiconsIcon
              icon={
                outcome.failed === 0 ? CheckmarkCircle01Icon : Alert02Icon
              }
              size={11}
              strokeWidth={2.4}
            />
            {outcome.confirmed}/{outcome.total} paid
          </span>
        ) : (
          <FancyButton
            type="button"
            variant="primary"
            size="sm"
            disabled={disabled}
            onClick={onRun}
          >
            {running ? "Running…" : `Run ${group.members.length}`}
            {!running && (
              <HugeiconsIcon
                icon={ArrowRight01Icon}
                size={12}
                strokeWidth={2.2}
              />
            )}
          </FancyButton>
        )}
      </header>

      <ul className="flex flex-col divide-y divide-border/60 rounded-lg border border-border/60 bg-background/40">
        {group.members.map((m) => (
          <li
            key={m.id}
            className="flex items-center justify-between gap-3 px-3 py-2 text-[12.5px]"
          >
            <span className="flex min-w-0 flex-col">
              <span className="truncate font-medium text-foreground">
                {m.name}
              </span>
              <span className="truncate font-mono text-[11px] text-muted-foreground">
                {shortAddr(m.wallet)}
              </span>
            </span>
            <span className="shrink-0 font-mono text-[12px] text-foreground/90">
              {m.schedule?.amount} {group.token.id}
            </span>
          </li>
        ))}
      </ul>

      {outcome?.depositSignature && (
        <p className="text-[11px] text-muted-foreground">
          Batch deposit:{" "}
          <a
            href={solscanTxUrl(outcome.depositSignature)}
            target="_blank"
            rel="noreferrer"
            className="font-mono text-foreground/80 underline underline-offset-2"
          >
            {shortSig(outcome.depositSignature)} ↗
          </a>
        </p>
      )}
    </div>
  );
}

function shortAddr(s: string): string {
  if (!s) return "";
  if (s.length <= 14) return s;
  return `${s.slice(0, 6)}…${s.slice(-6)}`;
}

function shortSig(s: string): string {
  if (s.length <= 10) return s;
  return `${s.slice(0, 4)}…${s.slice(-4)}`;
}
